cslc csl/layout.csl --arch=wse3 --fabric-dims=762,1172 --fabric-offsets=4,1 --params=P:180,Mt:12,Kt:12,Nt:12 --memcpy --channels=1 -o out
