cslc csl/layout.csl --arch=wse3 --fabric-dims=762,1172 --fabric-offsets=4,1 --params=P:4,Mt:14,Kt:14,Nt:14 --memcpy --channels=1 -o out
