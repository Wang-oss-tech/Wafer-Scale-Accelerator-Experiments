cslc csl/layout.csl --arch=wse3 --fabric-dims=762,1172 --fabric-offsets=4,1 --params=P:16,Mt:28,Kt:28,Nt:28 --memcpy --channels=1 -o out
